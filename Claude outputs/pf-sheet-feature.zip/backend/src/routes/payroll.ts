import { Router } from 'express'
import { authenticate, requireSuperAdmin } from '../middleware/auth'
import { prisma } from '../utils/prisma'
import { AppError } from '../middleware/errorHandler'
import { createAuditLog } from '../middleware/audit'
import { AuditAction, PayrollStatus } from '@prisma/client'
import { calculatePayrollForEmployee, isBonusMonth, getEsiConfig, getSalaryInputForDate } from '../services/payrollEngine'
import { buildEntryRows, buildExtraRows, writePfSheet } from '../services/pfSheetService'
import { saveFile, readFile, deleteFile } from '../utils/fileStorage'

export const payrollRouter = Router()
payrollRouter.use(authenticate)

// ─── GET ALL CYCLES ──────────────────────────────────────────────────────────

payrollRouter.get('/cycles', async (_req, res) => {
  const cycles = await prisma.payrollCycle.findMany({
    orderBy: { cycleStart: 'desc' },
    take: 24,
  })
  res.json({ success: true, data: cycles })
})

// ─── GET CYCLE DETAIL ────────────────────────────────────────────────────────

payrollRouter.get("/cycles/:id", requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({
    where: { id: req.params.id },
    include: {
      entries: {
        include: {
          employee: { select: { id: true, name: true, employeeCode: true, department: true } },
          payslip: { select: { id: true, status: true, pdfUrl: true, generatedAt: true, emailedAt: true } },
        },
      },
    },
  })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  res.json({ success: true, data: cycle })
})

// ─── CREATE CYCLE ─────────────────────────────────────────────────────────────

payrollRouter.post('/cycles', requireSuperAdmin, async (req, res) => {
  const { cycleStart, cycleEnd, payrollMonth } = req.body
  const existing = await prisma.payrollCycle.findFirst({ where: { payrollMonth } })
  if (existing) throw new AppError(`Payroll cycle for ${payrollMonth} already exists`, 409)

  const start = new Date(cycleStart)
  const end   = new Date(cycleEnd)
  const cycle = await prisma.payrollCycle.create({
    data: {
      cycleStart: start,
      cycleEnd:   end,
      payrollMonth,
      payrollDate: new Date(end.getFullYear(), end.getMonth(), 27),
      payslipDate: new Date(end.getFullYear(), end.getMonth() + 1, 5),
      salaryDate:  new Date(end.getFullYear(), end.getMonth() + 1, 0),
    },
  })
  res.status(201).json({ success: true, data: cycle })
})

// ─── HELPER: build salaryInput from employee record ───────────────────────────

function buildSalaryInput(emp: any) {
  return {
    annualCtc:        Number(emp.annualCtc),
    basicPercent:     Number(emp.basicPercent    ?? 45),
    hraPercent:       Number(emp.hraPercent      ?? 35),
    transportMonthly: emp.transportMonthly != null ? Number(emp.transportMonthly) : null,
    fbpMonthly:       emp.fbpMonthly       != null ? Number(emp.fbpMonthly)       : null,
    mediclaim:        Number(emp.mediclaim        ?? 0),
    hasIncentive:     Boolean(emp.hasIncentive),
    incentivePercent: Number(emp.incentivePercent ?? 12),
  }
}

// ─── RUN PAYROLL ─────────────────────────────────────────────────────────────

payrollRouter.post('/cycles/:id/run', requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({ where: { id: req.params.id } })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  if (cycle.status === PayrollStatus.LOCKED || cycle.status === PayrollStatus.DISBURSED) {
    throw new AppError('Cannot run payroll on a locked or disbursed cycle', 400)
  }

  const employees = await prisma.employee.findMany({
    where: { status: { in: ['ACTIVE', 'ON_NOTICE'] } },
  })

  // Fetch skipped employees for this month
  const skippedIds = new Set(
    (await prisma.payrollSkip.findMany({
      where: { payrollMonth: cycle.payrollMonth },
      select: { employeeId: true },
    })).map(s => s.employeeId)
  )

  const activeEmployees = employees.filter(e => !skippedIds.has(e.id))
  const activeIds = new Set(activeEmployees.map(e => e.id))

  // On re-run: remove entries for employees who are now separated/inactive
  // (they were active when payroll first ran but status changed since)
  const existingEntries = await prisma.payrollEntry.findMany({
    where:  { cycleId: cycle.id },
    select: { employeeId: true },
  })
  const staleIds = existingEntries
    .map(e => e.employeeId)
    .filter(id => !activeIds.has(id) && !skippedIds.has(id))
  if (staleIds.length > 0) {
    await prisma.payrollEntry.deleteMany({
      where: { cycleId: cycle.id, employeeId: { in: staleIds } },
    })
  }

  // Remove any existing entries for skipped employees (in case of re-run)
  if (skippedIds.size > 0) {
    await prisma.payrollEntry.deleteMany({
      where: { cycleId: cycle.id, employeeId: { in: [...skippedIds] } },
    })
  }

  const results: any[] = []
  let totalGross = 0, totalNet = 0, totalPf = 0, totalEsi = 0, totalEmployerPf = 0, totalEmployerEsi = 0

  for (const emp of activeEmployees) {
    try {
      const lopEntry = await prisma.lopEntry.findUnique({
        where: { cycleId_employeeId: { cycleId: cycle.id, employeeId: emp.id } },
      })

      const reimbs = await prisma.reimbursement.aggregate({
        where: { cycleId: cycle.id, employeeId: emp.id, status: { in: ['APPROVED', 'PAID'] } },
        _sum: { amount: true },
      })

      const revisionInput = await getSalaryInputForDate(emp.id, cycle.cycleStart)
      // TDS is manually set per employee — always use live employee record value, not snapshot
      const tdsMonthly = Number(emp.tdsMonthly ?? 0) || revisionInput.tdsMonthly

      // Preserve any manually-set incentive across re-runs of the same cycle
      const existingEntry = await prisma.payrollEntry.findUnique({
        where: { cycleId_employeeId: { cycleId: cycle.id, employeeId: emp.id } },
        select: { incentive: true },
      })

      const calc = await calculatePayrollForEmployee({
        employeeId:      emp.id,
        salaryInput:     revisionInput,
        state:           emp.state || '',
        joiningDate:     emp.joiningDate,
        lastWorkingDay:  emp.lastWorkingDay,
        resignationDate: emp.resignationDate,
        cycleStart:      cycle.cycleStart,
        cycleEnd:        cycle.cycleEnd,
        payrollMonth:    cycle.payrollMonth,
        lopDays:         Number(lopEntry?.lopDays || 0),
        tdsMonthly:      tdsMonthly,
        reimbursements:  Number(reimbs._sum.amount || 0),
        incentive:       Number(existingEntry?.incentive || 0),
        employeeStatus:  emp.status,
        prebuiltSalary:  revisionInput.prebuiltSalary,
        isTrainee:       emp.isTrainee,
        stipendMonthly:  emp.isTrainee && emp.stipendMonthly ? Number(emp.stipendMonthly) : undefined,
      })

      const s = calc.salary
      const bonusThisCycle = isBonusMonth(cycle.payrollMonth)

      await prisma.payrollEntry.upsert({
        where:  { cycleId_employeeId: { cycleId: cycle.id, employeeId: emp.id } },
        create: {
          cycleId:           cycle.id,
          employeeId:        emp.id,
          annualCtc:         s.annualCtc,
          monthlyCtc:        s.grandTotalMonthly,
          basic:             s.basicMonthly,
          hra:               s.hraMonthly,
          transport:         s.transportMonthly,
          fbp:               s.fbpMonthly,
          hyi:               s.hyiMonthly,
          grossSalary:       s.grandTotalMonthly,
          annualBonus:       bonusThisCycle ? s.annualBonus : 0,
          isBolusMonth:      bonusThisCycle,
          totalDays:         calc.proration.totalDays,
          payableDays:       calc.proration.payableDays,
          isProrated:        calc.proration.isProrated,
          proratedGross:     calc.proration.proratedGross,
          incentive:         calc.incentive,
          incentiveTdsAmount: calc.deductions.incentiveTds,
          reimbursementTotal: calc.reimbursements,
          lopDays:           Number(lopEntry?.lopDays || 0),
          lopAmount:         calc.deductions.lop,
          pfAmount:          calc.deductions.pf,
          employerPfAmount:  calc.salary.employerPfMonthly,
          esiAmount:         calc.deductions.esi,
          employerEsiAmount: calc.salary.employerEsiMonthly,
          ptAmount:          calc.deductions.pt,
          tdsAmount:         calc.deductions.tds,
          incentiveRecovery: calc.deductions.incentiveRecovery,
          loanDeduction:     calc.deductions.loanDeduction,
          netSalary:         calc.netSalary,
          status:            'CALCULATED',
        },
        update: {
          annualCtc:         s.annualCtc,
          monthlyCtc:        s.grandTotalMonthly,
          basic:             s.basicMonthly,
          hra:               s.hraMonthly,
          transport:         s.transportMonthly,
          fbp:               s.fbpMonthly,
          hyi:               s.hyiMonthly,
          grossSalary:       s.grandTotalMonthly,
          annualBonus:       bonusThisCycle ? s.annualBonus : 0,
          isBolusMonth:      bonusThisCycle,
          totalDays:         calc.proration.totalDays,
          payableDays:       calc.proration.payableDays,
          isProrated:        calc.proration.isProrated,
          proratedGross:     calc.proration.proratedGross,
          incentive:         calc.incentive,
          incentiveTdsAmount: calc.deductions.incentiveTds,
          reimbursementTotal: calc.reimbursements,
          lopDays:           Number(lopEntry?.lopDays || 0),
          lopAmount:         calc.deductions.lop,
          pfAmount:          calc.deductions.pf,
          employerPfAmount:  calc.salary.employerPfMonthly,
          esiAmount:         calc.deductions.esi,
          employerEsiAmount: calc.salary.employerEsiMonthly,
          ptAmount:          calc.deductions.pt,
          tdsAmount:         calc.deductions.tds,
          incentiveRecovery: calc.deductions.incentiveRecovery,
          loanDeduction:     calc.deductions.loanDeduction,
          netSalary:         calc.netSalary,
          status:            'CALCULATED',
        },
      })

      totalGross       += s.grandTotalMonthly
      totalNet         += calc.netSalary
      totalPf          += calc.deductions.pf
      totalEmployerPf  += calc.salary.employerPfMonthly
      totalEsi         += calc.deductions.esi
      totalEmployerEsi += calc.salary.employerEsiMonthly
      results.push({ employeeId: emp.id, name: emp.name, netSalary: calc.netSalary, status: 'ok' })
    } catch (err: any) {
      results.push({ employeeId: emp.id, name: emp.name, status: 'error', error: err.message })
    }
  }

  await prisma.payrollCycle.update({
    where: { id: cycle.id },
    data: {
      status: PayrollStatus.CALCULATED,
      runAt: new Date(),
      runBy: req.user!.id,
      totalGross,
      totalNet,
      totalPf,
      totalEmployerPf,
      totalEsi,
      totalEmployerEsi,
      employeeCount: activeEmployees.length,
    },
  })

  await createAuditLog({
    user: req.user!,
    action: AuditAction.PAYROLL_RUN,
    recordId: cycle.id,
    description: `Payroll run for ${cycle.payrollMonth} — ${employees.length} employees`,
  })

  // Leave module hooks — auto-approve pending leaves + take monthly balance snapshot
  try {
    const { autoApprovePendingLeaves, takeMonthlySnapshot } = await import('../services/leaveService')
    await autoApprovePendingLeaves()
    await takeMonthlySnapshot(cycle.id, cycle.payrollMonth)
  } catch (err) {
    console.error('[LEAVE] Leave hooks failed on payroll run:', err)
  }

  res.json({ success: true, data: { cycle: cycle.payrollMonth, results, totalGross, totalNet } })
})


// ─── DRY RUN (no DB writes) ───────────────────────────────────────────────────

payrollRouter.post('/dry-run', requireSuperAdmin, async (req, res) => {
  const { cycleStart, cycleEnd, payrollMonth, overrides = {} } = req.body
  if (!cycleStart || !cycleEnd || !payrollMonth) {
    throw new AppError('cycleStart, cycleEnd and payrollMonth are required', 400)
  }

  const start = new Date(cycleStart)
  const end   = new Date(cycleEnd)

  // Fetch shared data once upfront
  const [allEmployees, esiConfig, skippedSkips] = await Promise.all([
    prisma.employee.findMany({
      where: { status: { in: ['ACTIVE', 'ON_NOTICE'] } },
      orderBy: { name: 'asc' },
    }),
    getEsiConfig(),
    prisma.payrollSkip.findMany({ where: { payrollMonth }, select: { employeeId: true } }),
  ])

  const skippedIds = new Set(skippedSkips.map(s => s.employeeId))
  const employees = allEmployees.filter(e => !skippedIds.has(e.id))

  const bonusMonth = isBonusMonth(payrollMonth)

  // Process all employees in parallel
  const settled = await Promise.allSettled(
    employees.map(async (emp) => {
      const override = overrides[emp.id] || {}
      let lopDays     = override.lopDays      !== undefined ? Number(override.lopDays)       : 0
      let reimbAmount = override.reimbursements !== undefined ? Number(override.reimbursements) : 0

      if (override.lopDays === undefined || override.reimbursements === undefined) {
        const [lopEntry, reimbs] = await Promise.all([
          prisma.lopEntry.findFirst({ where: { employeeId: emp.id, cycle: { payrollMonth } } }),
          prisma.reimbursement.aggregate({ where: { employeeId: emp.id, cycle: { payrollMonth }, status: { in: ['APPROVED', 'PAID'] } }, _sum: { amount: true } }),
        ])
        if (override.lopDays === undefined)        lopDays     = Number(lopEntry?.lopDays || 0)
        if (override.reimbursements === undefined)  reimbAmount = Number(reimbs._sum.amount || 0)
      }

      const revisionInput = await getSalaryInputForDate(emp.id, start)
      // TDS is manually set per employee — always use live employee record value
      const empTds = Number((emp as any).tdsMonthly ?? 0) || revisionInput.tdsMonthly

      const calc = await calculatePayrollForEmployee({
        employeeId:      emp.id,
        salaryInput:     revisionInput,
        state:           emp.state || '',
        joiningDate:     emp.joiningDate,
        lastWorkingDay:  emp.lastWorkingDay,
        resignationDate: emp.resignationDate,
        cycleStart:      start,
        cycleEnd:        end,
        payrollMonth,
        lopDays,
        tdsMonthly:      empTds,
        reimbursements:  reimbAmount,
        employeeStatus:  emp.status,
        esiConfig,
        prebuiltSalary:  revisionInput.prebuiltSalary,
        isTrainee:       emp.isTrainee,
        stipendMonthly:  emp.isTrainee && emp.stipendMonthly ? Number(emp.stipendMonthly) : undefined,
      })

      return { emp, calc, lopDays, reimbAmount }
    })
  )

  const results: any[] = []
  let totalGross = 0, totalNet = 0, totalPf = 0, totalEsi = 0, totalTds = 0, totalLoan = 0

  settled.forEach((result, i) => {
    const emp = employees[i]
    if (result.status === 'rejected') {
      results.push({
        employeeId: emp.id, employeeCode: emp.employeeCode,
        name: emp.name, department: emp.department,
        status: 'error', error: result.reason?.message || 'Unknown error', netSalary: 0,
      })
      return
    }
    const { calc, lopDays, reimbAmount } = result.value
    const s = calc.salary
    totalGross += calc.proration.proratedGross
    totalNet   += calc.netSalary
    totalPf    += calc.deductions.pf
    totalEsi   += calc.deductions.esi
    totalTds   += calc.deductions.tds
    totalLoan  += calc.deductions.loanDeduction
    results.push({
      employeeId:    emp.id,
      employeeCode:  emp.employeeCode,
      name:          emp.name,
      department:    emp.department,
      designation:   emp.jobTitle,
      annualCtc:     s.annualCtc,
      grossMonthly:  s.grandTotalMonthly,
      basic:         s.basicMonthly,
      hra:           s.hraMonthly,
      transport:     s.transportMonthly,
      fbp:           s.fbpMonthly,
      hyi:           s.hyiMonthly,
      annualBonus:   bonusMonth ? s.annualBonus : 0,
      isBonusMonth:  bonusMonth,
      totalDays:     calc.proration.totalDays,
      payableDays:   calc.proration.payableDays,
      isProrated:    calc.proration.isProrated,
      proratedGross: calc.proration.proratedGross,
      reimbursements:reimbAmount,
      lopDays,
      lopAmount:     calc.deductions.lop,
      pfAmount:          calc.deductions.pf,
      employerPfAmount:  Math.min(calc.salary.employerPfMonthly, 1800),
      esiAmount:         calc.deductions.esi,
      employerEsiAmount: calc.salary.employerEsiMonthly,
      ptAmount:      calc.deductions.pt,
      tdsAmount:     calc.deductions.tds,
      loanDeduction: calc.deductions.loanDeduction,
      netSalary:     calc.netSalary,
      status:        'ok',
    })
  })

  res.json({
    success: true,
    data: {
      payrollMonth, cycleStart, cycleEnd,
      isBonusMonth: bonusMonth,
      employeeCount: employees.length,
      summary: {
        totalGross: Math.round(totalGross * 100) / 100,
        totalNet:   Math.round(totalNet   * 100) / 100,
        totalPf:    Math.round(totalPf    * 100) / 100,
        totalEsi:   Math.round(totalEsi   * 100) / 100,
        totalTds:   Math.round(totalTds   * 100) / 100,
        totalLoan:  Math.round(totalLoan  * 100) / 100,
      },
      results,
    },
  })
})

// ─── LOCK CYCLE ───────────────────────────────────────────────────────────────

payrollRouter.post('/cycles/:id/lock', requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({
    where: { id: req.params.id },
    include: { entries: { select: { id: true, employeeId: true } } },
  })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  if (cycle.status !== PayrollStatus.CALCULATED) throw new AppError('Only calculated cycles can be locked', 400)

  // Apply loan deductions to schedule — idempotent: only PENDING rows for this month are touched
  const { applyLoanDeductionToSchedule } = await import('../services/payrollEngine')
  for (const entry of cycle.entries) {
    await applyLoanDeductionToSchedule({
      employeeId:   entry.employeeId,
      payrollMonth: cycle.payrollMonth,
      entryId:      entry.id,
    })
  }

  const updated = await prisma.payrollCycle.update({
    where: { id: req.params.id },
    data: { status: PayrollStatus.LOCKED, lockedAt: new Date(), lockedBy: req.user!.id },
  })

  await createAuditLog({ user: req.user!, action: AuditAction.PAYROLL_LOCK, recordId: cycle.id, description: `Locked ${cycle.payrollMonth}` })
  res.json({ success: true, data: updated })
})

// ─── UNLOCK CYCLE ─────────────────────────────────────────────────────────────

payrollRouter.post('/cycles/:id/unlock', requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({ where: { id: req.params.id } })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  if (cycle.status !== PayrollStatus.LOCKED) throw new AppError('Only locked cycles can be unlocked', 400)

  // Reverse loan deductions applied on lock — restore balances + mark rows PENDING again
  const applied = await prisma.loanRepayment.findMany({
    where: { cycleMonth: cycle.payrollMonth },
    include: { loan: true },
  })
  for (const rep of applied) {
    await prisma.$transaction(async (tx) => {
      await tx.loan.update({
        where: { id: rep.loanId },
        data: {
          totalRepaid:        { decrement: rep.amount },
          outstandingBalance: { increment: rep.amount },
          ...(rep.loan.status === 'CLOSED' ? { status: 'ACTIVE', closedAt: null, closureNote: null } : {}),
        },
      })
      await tx.loanSchedule.updateMany({
        where: { loanId: rep.loanId, cycleMonth: cycle.payrollMonth, status: 'DEDUCTED' },
        data:  { status: 'PENDING', actualAmount: 0 },
      })
      await tx.loanRepayment.delete({ where: { id: rep.id } })
    })
  }

  const updated = await prisma.payrollCycle.update({
    where: { id: req.params.id },
    data: {
      status:       PayrollStatus.CALCULATED,
      unlockedAt:   new Date(),
      unlockedBy:   req.user!.id,
      unlockReason: req.body.reason,
    },
  })

  await createAuditLog({ user: req.user!, action: AuditAction.PAYROLL_UNLOCK, recordId: cycle.id, description: `Unlocked ${cycle.payrollMonth}: ${req.body.reason}` })
  res.json({ success: true, data: updated })
})

// ─── DISBURSE ─────────────────────────────────────────────────────────────────

payrollRouter.post('/cycles/:id/disburse', requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({ where: { id: req.params.id } })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  if (cycle.status !== PayrollStatus.LOCKED) throw new AppError('Only locked cycles can be disbursed', 400)

  const updated = await prisma.payrollCycle.update({
    where: { id: req.params.id },
    data: { status: PayrollStatus.DISBURSED, disbursedAt: new Date(), disbursedBy: req.user!.id },
  })

  res.json({ success: true, data: updated })
})

// ─── UPDATE SINGLE ENTRY — recalculate on LOP/TDS/reimbursement change ────────

payrollRouter.put('/entries/:id', requireSuperAdmin, async (req, res) => {
  const entry = await prisma.payrollEntry.findUnique({
    where: { id: req.params.id },
    include: { cycle: true },
  })
  if (!entry) throw new AppError('Entry not found', 404)
  if (entry.cycle.status === 'LOCKED' || entry.cycle.status === 'DISBURSED') {
    throw new AppError('Cannot edit a locked or disbursed cycle', 400)
  }

  const { lopDays, tdsAmount, reimbursements, adjustmentNote, incentive, incentiveTdsAmount } = req.body

  const emp = await prisma.employee.findUnique({ where: { id: entry.employeeId } })
  if (!emp) throw new AppError('Employee not found', 404)

  const revisionInput = await getSalaryInputForDate(emp.id, entry.cycle.cycleStart)

  // Use overrides if provided, else keep existing entry values
  const finalLopDays      = lopDays      !== undefined ? Number(lopDays)      : Number(entry.lopDays)
  const finalTds          = tdsAmount    !== undefined ? Number(tdsAmount)    : Number(entry.tdsAmount)
  const finalReimb        = reimbursements !== undefined ? Number(reimbursements) : Number(entry.reimbursementTotal)
  const finalIncentive    = incentive    !== undefined ? Number(incentive)    : Number(entry.incentive)
  const finalIncentiveTds = incentiveTdsAmount !== undefined ? Number(incentiveTdsAmount) : undefined

  const calc = await calculatePayrollForEmployee({
    employeeId:     emp.id,
    salaryInput:    revisionInput,
    state:          emp.state || '',
    joiningDate:    emp.joiningDate,
    lastWorkingDay: emp.lastWorkingDay,
    resignationDate:emp.resignationDate,
    cycleStart:     entry.cycle.cycleStart,
    cycleEnd:       entry.cycle.cycleEnd,
    payrollMonth:   entry.cycle.payrollMonth,
    lopDays:        finalLopDays,
    tdsMonthly:     finalTds,
    reimbursements: finalReimb,
    incentive:      finalIncentive,
    incentiveTds:   finalIncentiveTds,
    employeeStatus: emp.status,
    prebuiltSalary: revisionInput.prebuiltSalary,
    isTrainee:      emp.isTrainee,
    stipendMonthly: emp.isTrainee && emp.stipendMonthly ? Number(emp.stipendMonthly) : undefined,
  })

  const s = calc.salary
  const bonusThisCycle = isBonusMonth(entry.cycle.payrollMonth)

  const updated = await prisma.payrollEntry.update({
    where: { id: req.params.id },
    data: {
      basic:              s.basicMonthly,
      hra:                s.hraMonthly,
      transport:          s.transportMonthly,
      fbp:                s.fbpMonthly,
      hyi:                s.hyiMonthly,
      grossSalary:        s.grandTotalMonthly,
      annualBonus:        bonusThisCycle ? s.annualBonus : 0,
      isBolusMonth:       bonusThisCycle,
      totalDays:          calc.proration.totalDays,
      payableDays:        calc.proration.payableDays,
      isProrated:         calc.proration.isProrated,
      proratedGross:      calc.proration.proratedGross,
      incentive:          calc.incentive,
      incentiveTdsAmount: calc.deductions.incentiveTds,
      reimbursementTotal: finalReimb,
      lopDays:            finalLopDays,
      lopAmount:          calc.deductions.lop,
      pfAmount:           calc.deductions.pf,
      esiAmount:          calc.deductions.esi,
      ptAmount:           calc.deductions.pt,
      tdsAmount:          finalTds,
      incentiveRecovery:  calc.deductions.incentiveRecovery,
      loanDeduction:      calc.deductions.loanDeduction,
      netSalary:          calc.netSalary,
      adjustmentNote:     adjustmentNote ?? entry.adjustmentNote,
      adjustedBy:         req.user!.id,
      status:             'ADJUSTED',
    },
  })

  // Update cycle totals
  const allEntries = await prisma.payrollEntry.findMany({
    where: { cycleId: entry.cycleId },
    select: { grossSalary: true, netSalary: true, pfAmount: true, esiAmount: true },
  })
  await prisma.payrollCycle.update({
    where: { id: entry.cycleId },
    data: {
      totalGross: allEntries.reduce((s, e) => s + Number(e.grossSalary), 0),
      totalNet:   allEntries.reduce((s, e) => s + Number(e.netSalary),   0),
      totalPf:             allEntries.reduce((s, e) => s + Number(e.pfAmount),           0),
      totalEmployerPf:     allEntries.reduce((s, e) => s + Number((e as any).employerPfAmount  || 0), 0),
      totalEsi:            allEntries.reduce((s, e) => s + Number(e.esiAmount),          0),
      totalEmployerEsi:    allEntries.reduce((s, e) => s + Number((e as any).employerEsiAmount || 0), 0),
    },
  })

  res.json({ success: true, data: updated })
})

// ─── ADD INCENTIVE ON A LOCKED/DISBURSED CYCLE (single employee) ─────────────
// Scoped correction — does NOT unlock the cycle, does NOT touch other employees.
// Use for backdated incentives after the cycle is already locked/disbursed.
// Follow up with POST /payslips/regenerate/:entryId to regenerate that payslip.

payrollRouter.put('/entries/:id/incentive-locked', requireSuperAdmin, async (req, res) => {
  const entry = await prisma.payrollEntry.findUnique({
    where: { id: req.params.id },
    include: { cycle: true },
  })
  if (!entry) throw new AppError('Entry not found', 404)
  if (entry.cycle.status !== 'LOCKED' && entry.cycle.status !== 'DISBURSED') {
    throw new AppError('Use PUT /entries/:id for an unlocked cycle', 400)
  }

  const { incentive, incentiveTdsAmount, note } = req.body
  if (incentive === undefined) throw new AppError('incentive amount is required', 400)
  if (!note) throw new AppError('note (reason) is required', 400)

  const emp = await prisma.employee.findUnique({ where: { id: entry.employeeId } })
  if (!emp) throw new AppError('Employee not found', 404)

  const revisionInput = await getSalaryInputForDate(emp.id, entry.cycle.cycleStart)
  const finalIncentive    = Number(incentive)
  const finalIncentiveTds = incentiveTdsAmount !== undefined ? Number(incentiveTdsAmount) : undefined

  // Keep all other entry values (lop/tds/reimbursements) exactly as already locked —
  // only the incentive + its TDS are added on top.
  const calc = await calculatePayrollForEmployee({
    employeeId:      emp.id,
    salaryInput:     revisionInput,
    state:           emp.state || '',
    joiningDate:     emp.joiningDate,
    lastWorkingDay:  emp.lastWorkingDay,
    resignationDate: emp.resignationDate,
    cycleStart:      entry.cycle.cycleStart,
    cycleEnd:        entry.cycle.cycleEnd,
    payrollMonth:    entry.cycle.payrollMonth,
    lopDays:         Number(entry.lopDays),
    tdsMonthly:      Number(entry.tdsAmount),
    reimbursements:  Number(entry.reimbursementTotal),
    incentive:       finalIncentive,
    incentiveTds:    finalIncentiveTds,
    employeeStatus:  emp.status,
    prebuiltSalary:  revisionInput.prebuiltSalary,
    isTrainee:       emp.isTrainee,
    stipendMonthly:  emp.isTrainee && emp.stipendMonthly ? Number(emp.stipendMonthly) : undefined,
  })

  const updated = await prisma.payrollEntry.update({
    where: { id: req.params.id },
    data: {
      incentive:          calc.incentive,
      incentiveTdsAmount: calc.deductions.incentiveTds,
      netSalary:          calc.netSalary,
      adjustmentNote:     `[Locked-cycle incentive] ${note}`,
      adjustedBy:         req.user!.id,
      status:             'ADJUSTED',
    },
  })

  // Update cycle totals
  const allEntries = await prisma.payrollEntry.findMany({
    where: { cycleId: entry.cycleId },
    select: { grossSalary: true, netSalary: true, pfAmount: true, esiAmount: true },
  })
  await prisma.payrollCycle.update({
    where: { id: entry.cycleId },
    data: {
      totalGross: allEntries.reduce((s, e) => s + Number(e.grossSalary), 0),
      totalNet:   allEntries.reduce((s, e) => s + Number(e.netSalary),   0),
    },
  })

  await createAuditLog({
    user: req.user!,
    action: AuditAction.PAYROLL_INCENTIVE_ADJUST,
    recordId: entry.id,
    description: `Locked-cycle incentive ₹${finalIncentive} added for ${emp.name} — ${entry.cycle.payrollMonth}: ${note}`,
  })

  res.json({ success: true, data: updated })
})

// ─── GET EMPLOYEE ENTRIES ─────────────────────────────────────────────────────

payrollRouter.get('/employee/:employeeId', async (req, res) => {
  const entries = await prisma.payrollEntry.findMany({
    where: { employeeId: req.params.employeeId },
    include: { cycle: { select: { payrollMonth: true, status: true } } },
    orderBy: { createdAt: 'desc' },
    take: 24,
  })
  res.json({ success: true, data: entries })
})

// ─── REPORTS ─────────────────────────────────────────────────────────────────

payrollRouter.get('/cycles/:id/summary', requireSuperAdmin, async (req, res) => {
  const entries = await prisma.payrollEntry.findMany({
    where: { cycleId: req.params.id },
    include: { employee: { select: { name: true, employeeCode: true, department: true } } },
    orderBy: { employee: { name: 'asc' } },
  })
  res.json({ success: true, data: entries })
})

// ─── PAYROLL SKIP MANAGEMENT ──────────────────────────────────────────────────

// GET skips for a month
payrollRouter.get('/skips/:payrollMonth', requireSuperAdmin, async (req, res) => {
  const skips = await prisma.payrollSkip.findMany({
    where: { payrollMonth: req.params.payrollMonth },
    include: { employee: { select: { id: true, name: true, employeeCode: true, department: true } } },
    orderBy: { createdAt: 'desc' },
  })
  res.json({ success: true, data: skips })
})

// POST add a skip
payrollRouter.post('/skips', requireSuperAdmin, async (req, res) => {
  const { employeeId, payrollMonth, reason } = req.body
  if (!employeeId || !payrollMonth) throw new AppError('employeeId and payrollMonth are required', 400)

  const employee = await prisma.employee.findUnique({ where: { id: employeeId } })
  if (!employee) throw new AppError('Employee not found', 404)

  const skip = await prisma.payrollSkip.upsert({
    where: { employeeId_payrollMonth: { employeeId, payrollMonth } },
    create: { employeeId, payrollMonth, reason: reason || null, skippedBy: req.user!.id, skippedByName: req.user!.name },
    update: { reason: reason || null, skippedBy: req.user!.id, skippedByName: req.user!.name },
  })
  res.json({ success: true, data: skip })
})

// DELETE remove a skip
payrollRouter.delete('/skips/:id', requireSuperAdmin, async (req, res) => {
  await prisma.payrollSkip.delete({ where: { id: req.params.id } })
  res.json({ success: true })
})


// ─── PF SHEET ─────────────────────────────────────────────────────────────────

const PF_CONTAINER = 'pf-sheets'
const PF_ALLOWED: PayrollStatus[] = [PayrollStatus.CALCULATED, PayrollStatus.LOCKED, PayrollStatus.DISBURSED]

// Employees for the PF sheet window: in-cycle entries + candidates to add
payrollRouter.get('/cycles/:id/pf-sheet/employees', requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({ where: { id: req.params.id } })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  if (!PF_ALLOWED.includes(cycle.status)) throw new AppError('Payroll not calculated yet', 400)

  const entries = await prisma.payrollEntry.findMany({
    where: { cycleId: cycle.id },
    include: { employee: { select: { id: true, name: true, employeeCode: true, department: true } } },
  })
  const entryIds = entries.map(e => e.employeeId)

  const [others, skips] = await Promise.all([
    prisma.employee.findMany({
      where: { status: { in: ['ACTIVE', 'ON_NOTICE'] }, id: { notIn: entryIds } },
      select: { id: true, name: true, employeeCode: true, department: true, status: true },
      orderBy: { name: 'asc' },
    }),
    prisma.payrollSkip.findMany({ where: { payrollMonth: cycle.payrollMonth }, select: { employeeId: true, reason: true } }),
  ])
  const skipMap = new Map(skips.map(s => [s.employeeId, s.reason || 'Skipped']))

  res.json({
    success: true,
    data: {
      cycleId: cycle.id,
      payrollMonth: cycle.payrollMonth,
      status: cycle.status,
      entries: entries
        .map(e => ({
          id: e.employee.id, name: e.employee.name, employeeCode: e.employee.employeeCode,
          department: e.employee.department, gross: Number(e.proratedGross), net: Number(e.netSalary),
        }))
        .sort((a, b) => a.name.localeCompare(b.name)),
      others: others.map(o => ({ ...o, skipReason: skipMap.get(o.id) || null })),
    },
  })
})

// Generate + save + return the sheet
payrollRouter.post('/cycles/:id/pf-sheet/export', requireSuperAdmin, async (req, res) => {
  const cycle = await prisma.payrollCycle.findUnique({ where: { id: req.params.id } })
  if (!cycle) throw new AppError('Payroll cycle not found', 404)
  if (!PF_ALLOWED.includes(cycle.status)) throw new AppError('Payroll not calculated yet', 400)

  const entryEmployeeIds: string[] = Array.isArray(req.body?.entryEmployeeIds) ? req.body.entryEmployeeIds : []
  const extraRaw: string[] = Array.isArray(req.body?.extraEmployeeIds) ? req.body.extraEmployeeIds : []
  const note: string | null = req.body?.note ? String(req.body.note).slice(0, 500) : null
  if (!entryEmployeeIds.length && !extraRaw.length) throw new AppError('Select at least one employee', 400)

  const entryRows = await buildEntryRows(cycle.id, entryEmployeeIds)
  const entryIdSet = new Set((await prisma.payrollEntry.findMany({ where: { cycleId: cycle.id }, select: { employeeId: true } })).map(e => e.employeeId))
  const extraIds = extraRaw.filter(id => !entryIdSet.has(id))
  const extraRows = await buildExtraRows(cycle.payrollMonth, extraIds)

  const rows = [...entryRows, ...extraRows]
  if (!rows.length) throw new AppError('No employees to export', 400)

  const buf = await writePfSheet(rows)
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)
  const fileName = `pf-sheet-${cycle.payrollMonth}.xlsx`
  const fileKey = `${cycle.payrollMonth}/pf-sheet-${cycle.payrollMonth}-${stamp}.xlsx`
  await saveFile(PF_CONTAINER, fileKey, buf)

  const rec = await prisma.pfSheetExport.create({
    data: {
      cycleId: cycle.id,
      payrollMonth: cycle.payrollMonth,
      entryEmployeeIds: entryRows.map(r => r.employeeId),
      extraEmployeeIds: extraRows.map(r => r.employeeId),
      employeeCount: rows.length,
      fileKey, fileName, note,
      generatedById: req.user!.id,
      generatedByName: req.user!.name,
    },
  })

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`)
  res.setHeader('X-Pf-Sheet-Id', rec.id)
  res.send(buf)
})

// History list
payrollRouter.get('/pf-sheets', requireSuperAdmin, async (req, res) => {
  const year = req.query.year ? String(req.query.year) : ''
  const list = await prisma.pfSheetExport.findMany({
    where: year ? { payrollMonth: { startsWith: year } } : {},
    orderBy: { createdAt: 'desc' },
    take: 200,
  })
  res.json({
    success: true,
    data: list.map(({ entryEmployeeIds, extraEmployeeIds, fileKey, ...rest }) => ({
      ...rest,
      paidCount: entryEmployeeIds.length,
      extraCount: extraEmployeeIds.length,
    })),
  })
})

// History detail — employee list
payrollRouter.get('/pf-sheets/:id', requireSuperAdmin, async (req, res) => {
  const rec = await prisma.pfSheetExport.findUnique({ where: { id: req.params.id } })
  if (!rec) throw new AppError('PF sheet not found', 404)
  const emps = await prisma.employee.findMany({
    where: { id: { in: [...rec.entryEmployeeIds, ...rec.extraEmployeeIds] } },
    select: { id: true, name: true, employeeCode: true, department: true },
    orderBy: { name: 'asc' },
  })
  const extra = new Set(rec.extraEmployeeIds)
  res.json({ success: true, data: { ...rec, employees: emps.map(e => ({ ...e, isExtra: extra.has(e.id) })) } })
})

// History download — saved file
payrollRouter.get('/pf-sheets/:id/download', requireSuperAdmin, async (req, res) => {
  const rec = await prisma.pfSheetExport.findUnique({ where: { id: req.params.id } })
  if (!rec) throw new AppError('PF sheet not found', 404)
  const buf = await readFile(PF_CONTAINER, rec.fileKey)
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  res.setHeader('Content-Disposition', `attachment; filename="${rec.fileName}"`)
  res.send(buf)
})

// History delete
payrollRouter.delete('/pf-sheets/:id', requireSuperAdmin, async (req, res) => {
  const rec = await prisma.pfSheetExport.findUnique({ where: { id: req.params.id } })
  if (!rec) throw new AppError('PF sheet not found', 404)
  await deleteFile(PF_CONTAINER, rec.fileKey)
  await prisma.pfSheetExport.delete({ where: { id: rec.id } })
  res.json({ success: true })
})
