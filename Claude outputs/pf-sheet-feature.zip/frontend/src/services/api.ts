import axios from 'axios'
import { useAuthStore } from '../store/authStore'
import { msalInstance, loginRequest } from './msal'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:4000',
  timeout: 30000,
})

api.interceptors.request.use((config) => {
  const { token, user, isDevMode } = useAuthStore.getState()
  if (isDevMode && user) {
    config.headers['x-dev-role'] = user.role
    config.headers['x-dev-user-id'] = user.id
  } else if (token) {
    config.headers['Authorization'] = `Bearer ${token}`
  }
  return config
})

// Track if we're already refreshing to avoid infinite loops
let isRefreshing = false
let refreshQueue: Array<(token: string) => void> = []

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    const { isDevMode, setUser, logout } = useAuthStore.getState()

    if (err.response?.status === 401 && !isDevMode && !err.config._retry) {
      const errorCode = err.response?.data?.code
      // Only attempt refresh for expired/invalid tokens — not for other 401s
      if (errorCode && !['TOKEN_EXPIRED', 'INVALID_TOKEN', 'NO_TOKEN', 'AUTH_FAILED'].includes(errorCode)) {
        return Promise.reject(err)
      }
      // Try silent token refresh before giving up
      if (isRefreshing) {
        // Queue this request until refresh completes
        return new Promise((resolve, reject) => {
          refreshQueue.push((newToken: string) => {
            err.config._retry = true
            err.config.headers['Authorization'] = `Bearer ${newToken}`
            resolve(api(err.config))
          })
        })
      }

      isRefreshing = true
      err.config._retry = true

      try {
        const accounts = msalInstance.getAllAccounts()
        if (accounts.length === 0) throw new Error('No accounts')

        const result = await msalInstance.acquireTokenSilent({
          ...loginRequest,
          account: accounts[0],
          forceRefresh: true,
        })

        const newToken = result.idToken

        // Update stored token
        const { user } = useAuthStore.getState()
        if (user) setUser(user, newToken)

        // Flush queued requests
        refreshQueue.forEach(cb => cb(newToken))
        refreshQueue = []
        isRefreshing = false

        // Retry original request with new token
        err.config.headers['Authorization'] = `Bearer ${newToken}`
        return api(err.config)
      } catch (refreshErr) {
        refreshQueue = []
        isRefreshing = false

        // Only logout if MSAL has no accounts at all (truly signed out)
        // Transient failures (network, DB down) should NOT log the user out
        const accounts = msalInstance.getAllAccounts()
        if (accounts.length === 0) {
          logout()
          window.location.href = '/login?expired=1'
        }
        // Otherwise silently fail — user stays logged in, request just fails
        return Promise.reject(refreshErr)
      }
    }

    return Promise.reject(err)
  }
)

export default api

export const employeeApi = {
  list: (params?: Record<string, any>) => api.get('/api/employees', { params }),
  get: (id: string) => api.get(`/api/employees/${id}`),
  getFull: (id: string) => api.get(`/api/employees/${id}/full`),
  nextCode: (type: 'EMPLOYEE' | 'TRAINEE') => api.get(`/api/employees/next-code?type=${type}`),
  delete: (id: string) => api.delete(`/api/employees/${id}`),
  create: (data: any) => api.post('/api/employees', data),
  update: (id: string, data: any) => api.put(`/api/employees/${id}`, data),
  deactivate: (id: string) => api.post(`/api/employees/${id}/deactivate`),
  convertToEmployee: (id: string, traineeEndDate: string) => api.post(`/api/employees/${id}/convert-to-employee`, { traineeEndDate }),
  payrollHistory: (id: string) => api.get(`/api/employees/${id}/payroll-history`),
  salaryRevisions: (id: string) => api.get(`/api/employees/${id}/salary-revisions`),
}

export const payrollApi = {
  cycles: () => api.get('/api/payroll/cycles'),
  cycle: (id: string) => api.get(`/api/payroll/cycles/${id}`),
  createCycle: (data: any) => api.post('/api/payroll/cycles', data),
  run: (id: string) => api.post(`/api/payroll/cycles/${id}/run`),
  lock: (id: string) => api.post(`/api/payroll/cycles/${id}/lock`),
  unlock: (id: string, reason: string) => api.post(`/api/payroll/cycles/${id}/unlock`, { reason }),
  disburse: (id: string) => api.post(`/api/payroll/cycles/${id}/disburse`),
  adjustEntry: (id: string, data: any) => api.put(`/api/payroll/entries/${id}`, data),
  setIncentiveLocked: (id: string, data: { incentive: number; incentiveTdsAmount?: number; note: string }) =>
    api.put(`/api/payroll/entries/${id}/incentive-locked`, data),
  entriesForEmployee: (employeeId: string) => api.get(`/api/payroll/employee/${employeeId}`),
  preview: (data: any) => api.post('/api/payroll/dry-run', data),
  // PayrollSkip
  getSkips: (payrollMonth: string) => api.get(`/api/payroll/skips/${payrollMonth}`),
  addSkip: (data: { employeeId: string; payrollMonth: string; reason?: string }) => api.post('/api/payroll/skips', data),
  removeSkip: (id: string) => api.delete(`/api/payroll/skips/${id}`),
  // PF Sheet
  pfSheetEmployees: (cycleId: string) => api.get(`/api/payroll/cycles/${cycleId}/pf-sheet/employees`),
  pfSheetExport: (cycleId: string, data: { entryEmployeeIds: string[]; extraEmployeeIds: string[]; note?: string }) =>
    api.post(`/api/payroll/cycles/${cycleId}/pf-sheet/export`, data, { responseType: 'blob' }),
  pfSheets: (year?: string) => api.get('/api/payroll/pf-sheets', { params: year ? { year } : {} }),
  pfSheet: (id: string) => api.get(`/api/payroll/pf-sheets/${id}`),
  pfSheetDownload: (id: string) => api.get(`/api/payroll/pf-sheets/${id}/download`, { responseType: 'blob' }),
  pfSheetDelete: (id: string) => api.delete(`/api/payroll/pf-sheets/${id}`),
}

export const lopApi = {
  list: (cycleId: string) => api.get(`/api/lop/${cycleId}`),
  upsert: (data: any) => api.post('/api/lop', data),
}

export const reimbursementApi = {
  // Employee self-service
  my:        ()                                   => api.get('/api/reimbursements/my'),
  request:   (fd: FormData)                       => api.post('/api/reimbursements/request', fd),
  withdraw:  (id: string)                         => api.post(`/api/reimbursements/${id}/withdraw`),

  // Shared list + detail (SA/HR/Emp-own)
  listAll:   (params?: any)                       => api.get('/api/reimbursements', { params }),
  get:       (id: string)                         => api.get(`/api/reimbursements/${id}`),

  // SA actions
  openCycles:()                                   => api.get('/api/reimbursements/cycles/open'),
  saAdd:     (fd: FormData)                       => api.post('/api/reimbursements/sa/add', fd),
  approve:   (id: string, data: any)              => api.post(`/api/reimbursements/${id}/approve`, data),
  reject:    (id: string, reason: string)         => api.post(`/api/reimbursements/${id}/reject`, { reason }),
  patch:     (id: string, data: any)              => api.patch(`/api/reimbursements/${id}`, data),
  delete:    (id: string)                         => api.delete(`/api/reimbursements/${id}`),

  // Files
  addFiles:   (id: string, fd: FormData)          => api.post(`/api/reimbursements/${id}/files`, fd),
  deleteFile: (id: string, fileId: string)        => api.delete(`/api/reimbursements/${id}/files/${fileId}`),

  // Legacy (cycle summary) — kept for any old callers
  listForCycle: (cycleId: string)                 => api.get(`/api/reimbursements/cycle/${cycleId}`),
}

export const payslipApi = {
  forEmployee: (employeeId: string) => api.get(`/api/payslips/employee/${employeeId}`),
  generate: (cycleId: string) => api.post(`/api/payslips/generate/${cycleId}`),
  previewUrl: (payslipId: string) => api.get(`/api/payslips/${payslipId}/preview-url`),
  regenerate: (entryId: string) => api.post(`/api/payslips/regenerate/${entryId}`),
  emailOne: (payslipId: string) => api.post(`/api/payslips/email/${payslipId}`),
  emailAll: (cycleId: string) => api.post(`/api/payslips/email-all/${cycleId}`),
  // Payslip password
  passwordStatus: () => api.get('/api/employees/my/payslip-password-status'),
  verifyPassword: (password: string) => api.post('/api/employees/my/verify-payslip-password', { password }),
  setPassword: (data: { oldPassword?: string; newPassword: string }) => api.post('/api/employees/my/set-payslip-password', data),
  // HR/SA
  passwordInfo: (employeeId: string) => api.get(`/api/employees/${employeeId}/payslip-password-info`),
  allowPasswordReset: (employeeId: string, allow: boolean) => api.patch(`/api/employees/${employeeId}/allow-password-reset`, { allow }),
}

export const payslipVaultApi = {
  employees: () => api.get('/api/payslip-vault/employees'),
  companyReport: (from?: string, to?: string) =>
    api.get('/api/payslip-vault/company-report', { params: { from, to } }),
  employeePayslips: (employeeId: string) => api.get(`/api/payslip-vault/employees/${employeeId}/payslips`),
  months: () => api.get('/api/payslip-vault/months'),
  downloadSingle: (employeeId: string, months: string[]) =>
    api.post('/api/payslip-vault/download/single', { employeeId, months }, { responseType: 'blob' }),
  downloadBulk: (params: { employeeIds: string[]; months?: string[]; from?: string; to?: string }) =>
    api.post('/api/payslip-vault/download/bulk', params, { responseType: 'blob' }),
  salaryView: (employeeId: string, from?: string, to?: string) =>
    api.get(`/api/payslip-vault/salary-view/${employeeId}`, { params: { from, to } }),
  exportExcel: (params: { employeeIds: string[]; from?: string; to?: string }) =>
    api.post('/api/payslip-vault/export/excel', params, { responseType: 'blob' }),
}

export const loanApi = {
  list:        (params?: any) => api.get('/api/loans', { params }),
  pending:     ()             => api.get('/api/loans/pending'),
  my:          ()             => api.get('/api/loans/my'),
  get:         (id: string)   => api.get(`/api/loans/${id}`),
  forEmployee: (employeeId: string) => api.get(`/api/loans/employee/${employeeId}`),
  request:     (data: any)    => api.post('/api/loans/request', data),
  create:      (data: any)    => api.post('/api/loans', data),
  approve:     (id: string, data: any) => api.post(`/api/loans/${id}/approve`, data),
  reject:      (id: string, reason: string) => api.post(`/api/loans/${id}/reject`, { reason }),
  update:      (id: string, data: any) => api.patch(`/api/loans/${id}`, data),
  pauseMonth:  (id: string, sid: string, reason: string) => api.post(`/api/loans/${id}/schedule/${sid}/pause`, { reason }),
  resumeMonth: (id: string, sid: string) => api.post(`/api/loans/${id}/schedule/${sid}/resume`, {}),
  close:       (id: string, note: string) => api.post(`/api/loans/${id}/close`, { note }),
}

export const reportApi = {
  summary: () => api.get('/api/reports/summary'),
  trend: () => api.get('/api/reports/payroll-trend'),
  salarySummary: () => api.get('/api/reports/salary-summary'),
}

export const configApi = {
  get: () => api.get('/api/config'),
  update: (data: any) => api.put('/api/config', data),
  ptSlabs: () => api.get('/api/config/pt-slabs'),
}

export const auditApi = {
  list: (params?: any) => api.get('/api/audit', { params }),
}

export const fnfApi = {
  list:            ()           => api.get('/api/fnf'),
  eligible:        ()           => api.get('/api/fnf/eligible'),
  byEmployee:      (id: string) => api.get(`/api/fnf/employee/${id}`),
  get:             (id: string) => api.get(`/api/fnf/${id}`),
  calculate:       (empId: string, hyiOverrides?: Record<string, number>) => api.post(`/api/fnf/calculate/${empId}`, { hyiOverrides }),
  preview:         (empId: string, lastWorkingDay?: string) => api.post(`/api/fnf/preview/${empId}`, { lastWorkingDay }),
  initiate:        (empId: string, hyiOverrides?: Record<string, number>) => api.post(`/api/fnf/initiate/${empId}`, { hyiOverrides }),
  approve:         (id: string, notes?: string) => api.post(`/api/fnf/${id}/approve`, { notes }),
  settle:          (id: string, notes?: string) => api.post(`/api/fnf/${id}/settle`, { notes }),
  update:          (id: string, data: any) => api.put(`/api/fnf/${id}`, data),
  generatePdf:     (id: string) => api.post(`/api/fnf/${id}/generate-pdf`),
  emailStatement:  (id: string, email: string) => api.post(`/api/fnf/${id}/email`, { email }),
  emailToHr:       (id: string) => api.post(`/api/fnf/${id}/email-hr`),
  wizard: {
    getSession:   (empId: string) => api.get(`/api/fnf/wizard/${empId}`),
    getStepData:  (empId: string, hyiOverrides?: Record<string, number>) =>
      api.get(`/api/fnf/wizard/${empId}/step-data`, {
        params: hyiOverrides && Object.keys(hyiOverrides).length ? { hyiOverrides: JSON.stringify(hyiOverrides) } : {},
      }),
    confirmStep:  (empId: string, stepKey: string, data: { originalData: any; overrideData?: any; notes?: string }) =>
      api.post(`/api/fnf/wizard/${empId}/step/${stepKey}/confirm`, data),
    complete:     (empId: string) => api.post(`/api/fnf/wizard/${empId}/complete`),
    reset:        (empId: string) => api.delete(`/api/fnf/wizard/${empId}`),
    addLeave:     (empId: string, data: { leaveKind: string; startDate: string; endDate: string; isHalfDay?: boolean; halfDaySlot?: string; reasonLabel?: string }) =>
      api.post(`/api/fnf/wizard/${empId}/add-leave`, data),
    recalcHyi:    () => api.post(`/api/fnf/wizard/admin/recalc-hyi`),
  },
}

export const leaveApi = {
  // Policy
  policy:             ()           => api.get('/api/leave/policy'),
  updatePolicy:       (data: any)  => api.put('/api/leave/policy', data),

  // Reasons
  reasons:            (kind?: string) => api.get('/api/leave/reasons', { params: kind ? { kind } : {} }),
  addReason:          (data: any)  => api.post('/api/leave/reasons', data),
  updateReason:       (id: string, data: any) => api.put(`/api/leave/reasons/${id}`, data),
  deleteReason:       (id: string) => api.delete(`/api/leave/reasons/${id}`),

  // Public Holidays
  holidays:           (year?: number) => api.get('/api/leave/holidays', { params: year ? { year } : {} }),
  addHoliday:         (data: any)  => api.post('/api/leave/holidays', data),
  updateHoliday:      (id: string, data: any) => api.put(`/api/leave/holidays/${id}`, data),
  deleteHoliday:      (id: string) => api.delete(`/api/leave/holidays/${id}`),

  // Balance
  myBalance:          (year?: number) => api.get('/api/leave/balance/my', { params: year ? { year } : {} }),
  employeeBalance:    (id: string, year?: number) => api.get(`/api/leave/balance/${id}`, { params: year ? { year } : {} }),
  allBalances:        (year?: number) => api.get('/api/leave/balance', { params: year ? { year } : {} }),
  balanceHistory:     (id: string) => api.get(`/api/leave/balance/${id}/history`),

  // Applications
  apply:              (data: any)  => api.post('/api/leave/apply', data),
  myApplications:     (params?: any) => api.get('/api/leave/my', { params }),
  allApplications:    (params?: any) => api.get('/api/leave/applications', { params }),
  approve:            (id: string) => api.put(`/api/leave/applications/${id}/approve`, {}),
  decline:            (id: string, reason: string) => api.put(`/api/leave/applications/${id}/decline`, { reason }),
  cancelDirect:       (id: string, newEndDate?: string) => api.put(`/api/leave/applications/${id}/cancel-direct`, { newEndDate }),

  // Cancellation requests (employee)
  requestCancel:      (id: string, reason?: string) => api.post(`/api/leave/applications/${id}/cancel`, { reason }),
  cancellationRequests: () => api.get('/api/leave/cancellations'),
  approveCancellation: (id: string, newEndDate?: string) => api.put(`/api/leave/cancellations/${id}/approve`, { newEndDate }),
  declineCancellation: (id: string, reason: string) => api.put(`/api/leave/cancellations/${id}/decline`, { reason }),

  // Rollover
  rolloverStatus:     () => api.get('/api/leave/rollover/status'),
  triggerRollover:    () => api.post('/api/leave/rollover', {}),
  rolloverHistory:    () => api.get('/api/leave/rollover/history'),

  // Seed
  seedReasons:        () => api.post('/api/leave/seed-reasons', {}),
  balanceAdjustEmployees: (year?: number) => api.get('/api/leave/balance-adjust/employees', { params: year ? { year } : {} }),
  balanceAdjust:      (data: any) => api.put('/api/leave/balance-adjust', data),
  bulkEntry:          (entries: any[]) => api.post('/api/leave/bulk-entry', { entries }),

  // LOP Correction
  lopCorrectionPreview: () => api.get('/api/leave/admin/lop-correction/preview'),
  lopCorrectionApply:   () => api.post('/api/leave/admin/lop-correction/apply', {}),
}

export const policiesApi = {
  list:   ()                        => api.get('/api/policies'),
  create: (data: any)               => api.post('/api/policies', data),
  update: (id: string, data: any)   => api.put(`/api/policies/${id}`, data),
  delete: (id: string)              => api.delete(`/api/policies/${id}`),
  reorder:(ids: string[])           => api.put('/api/policies/reorder', { ids }),
}

export const calendarApi = {
  birthdays: (month: number) => api.get('/api/employees/birthdays/month', { params: { month } }),
}

export const exitApi = {
  get:              (id: string)                   => api.get(`/api/exit/${id}`),
  resign:           (id: string, data: any)        => api.post(`/api/exit/${id}/resign`, data),
  initiate:         (id: string, data: any)        => api.post(`/api/exit/${id}/initiate`, data),
  updateDetails:    (id: string, data: any)        => api.patch(`/api/exit/${id}/details`, data),
  updateClearance:  (id: string, data: any)        => api.patch(`/api/exit/${id}/clearance`, data),
  updateInterview:  (id: string, data: any)        => api.patch(`/api/exit/${id}/interview`, data),
  unlockFf:         (id: string)                   => api.patch(`/api/exit/${id}/ff-unlock`, {}),
  enableWithdrawal: (id: string, enabled: boolean) => api.patch(`/api/exit/${id}/enable-withdrawal`, { enabled }),
  withdraw:         (id: string)                   => api.post(`/api/exit/${id}/withdraw`, {}),
  convertLop:       (id: string, applicationId: string) => api.post(`/api/exit/${id}/convert-lop`, { applicationId }),
  separate:         (id: string)                   => api.post(`/api/exit/${id}/separate`, {}),
  lopLeaves:        (id: string)                   => api.get(`/api/exit/${id}/lop-leaves`),
  testEmail:        (toEmail: string)              => api.post('/api/config/test-email', { toEmail }),
}

export const cronApi = {
  logs:            (params?: any) => api.get('/api/cron/logs', { params }),
  triggerManual:   (job: string)  => api.post(`/api/cron/manual/${job}`),
}

export const teamsChatApi = {
  employees:  ()                 => api.get('/api/teams-chat/employees'),
  chats:      (entraId: string, nextLink?: string) =>
                api.get('/api/teams-chat/chats', { params: { entraId, nextLink } }),
  messages:   (chatId: string, nextLink?: string) =>
                api.get(`/api/teams-chat/chats/${chatId}/messages`, { params: { nextLink } }),
  deleteChat: (chatId: string)   => api.delete(`/api/teams-chat/chats/${chatId}`),
  bulkDelete: (chatIds: string[]) => api.post('/api/teams-chat/chats/bulk-delete', { chatIds }),
  scanBefore: (entraId: string, before: string) =>
                api.get('/api/teams-chat/chats/before', { params: { entraId, before } }),
  checkDeletedChat: (chatId: string) => api.get(`/api/teams-chat/deleted-chats/${encodeURIComponent(chatId)}`),
  restoreChat: (chatId: string) => api.post(`/api/teams-chat/deleted-chats/${encodeURIComponent(chatId)}/restore`),
}

export const assetApi = {
  // Config
  categories:          ()                        => api.get('/api/assets/config/categories'),
  createCategory:      (data: any)               => api.post('/api/assets/config/categories', data),
  updateCategory:      (id: string, data: any)   => api.put(`/api/assets/config/categories/${id}`, data),
  deleteCategory:      (id: string)              => api.delete(`/api/assets/config/categories/${id}`),
  createSubCategory:   (data: any)               => api.post('/api/assets/config/subcategories', data),
  updateSubCategory:   (id: string, data: any)   => api.put(`/api/assets/config/subcategories/${id}`, data),
  deleteSubCategory:   (id: string)              => api.delete(`/api/assets/config/subcategories/${id}`),

  // Assets
  list:              (params?: any)              => api.get('/api/assets', { params }),
  get:               (id: string)                => api.get(`/api/assets/${id}`),
  create:            (data: any)                 => api.post('/api/assets', data),
  update:            (id: string, data: any)     => api.put(`/api/assets/${id}`, data),
  updateStatus:      (id: string, status: string)=> api.patch(`/api/assets/${id}/status`, { status }),
  assign:            (id: string, data: any)     => api.post(`/api/assets/${id}/assign`, data),
  return:            (id: string, data: any)     => api.post(`/api/assets/${id}/return`, data),
  byEmployee:        (employeeId: string)        => api.get(`/api/assets/employee/${employeeId}`),
  myAssets:          ()                          => api.get('/api/assets/my'),
  bulkTemplate:      ()                          => api.get('/api/assets/bulk/template', { responseType: 'blob' }),
  bulkUpload:        (file: File)                => { const fd = new FormData(); fd.append('file', file); return api.post('/api/assets/bulk/upload', fd) },

  // Requests
  allRequests:       (params?: any)              => api.get('/api/assets/requests/all', { params }),
  myRequests:        ()                          => api.get('/api/assets/requests/my'),
  createRequest:     (data: any)                 => api.post('/api/assets/requests', data),
  reviewRequest:     (id: string, data: any)     => api.patch(`/api/assets/requests/${id}/review`, data),
}

export const documentsApi = {
  uploadLogo:      (formData: FormData) => api.post('/api/documents/company-logo', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  uploadSign:      (formData: FormData) => api.post('/api/documents/company-sign', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  getSalarySnapshot: (employeeId: string) => api.get(`/api/documents/salary-snapshot/${employeeId}`),
  computeSalary:   (data: { employeeId: string; annualCtc: number }) => api.post('/api/documents/compute-salary', data),
  generate:        (data: any) => api.post('/api/documents/generate', data),
  sendEmail:       (data: { employeeId: string; htmlContent: string; subject?: string }) => api.post('/api/documents/send-email', data),
  testEmail:       (data: { toEmail: string; employeeId?: string; htmlContent?: string }) => api.post('/api/documents/test-email', data),
  migrateHtmlPreview: () => api.get('/api/documents/migrate-html-preview'),
  migrateHtmlToPdf:   () => api.post('/api/documents/migrate-html-to-pdf'),
}
